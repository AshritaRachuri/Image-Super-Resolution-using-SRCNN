// Get references to the file input and drop zone
const fileInput = document.getElementById("fileInput");
const dropZone = document.getElementById("dropZone");

// Trigger file input on drop zone click
dropZone.addEventListener("click", () => {
  fileInput.click(); // Open the file dialog
});

// Handle file selection from file input
fileInput.addEventListener("change", () => {
  if (fileInput.files.length > 0) {
    const form = document.getElementById("uploadForm");
    form.submit();  // Submit the form
  }
});

// Handle drag-and-drop behavior
dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("drag-over"); // Optional: Add styles for drag-over
});

dropZone.addEventListener("dragleave", () => {
  dropZone.classList.remove("drag-over");
});

dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("drag-over");
  const files = e.dataTransfer.files;
  if (files.length > 0) {
    fileInput.files = files; // Assign the dropped file to the input
    const form = document.getElementById("uploadForm");
    form.submit();  // Submit the form
  }
});
