// document.addEventListener("DOMContentLoaded", () => {
//     const imageData = localStorage.getItem("selectedImage");
//     const imgElement = document.getElementById("selectedImage");
  
//     if (imageData) {
//       imgElement.src = imageData;
//     } else {
//       window.location.href = "../page1/index.html"; // Redirect to page 1 if no image is selected
//     }
  
//     document.getElementById("goBack").addEventListener("click", () => {
//       window.location.href = "../page1/index.html"; // Navigate back to page 1
//     });
  
//     document.getElementById("enhanceImage").addEventListener("click", () => {
//       window.location.href = "../page3/index.html"; // Navigate to page 3 for enhancement
//     });
// });
const change_img=document.getElementById("goBack")
change_img.addEventListener("click",()=>{
  window.location.href = "/";
})
