document.addEventListener("DOMContentLoaded", () => {
    //const imageData = localStorage.getItem("selectedImage");
    //const lowResImg = document.getElementById("lowResImage");
    const highResImg = document.getElementById("highResImage");
  
    // if (imageData) {
    //   lowResImg.src = imageData;
    //   highResImg.src = imageData; // Mock enhancement
    // } else {
    //   window.location.href = "../page1/index.html";
    // }
  
    document.getElementById("downloadImage").addEventListener("click", () => {
      const link = document.createElement("a");
      link.href = highResImg.src;
      link.download = "enhanced-image.png";
      link.click();
    });
  });
  